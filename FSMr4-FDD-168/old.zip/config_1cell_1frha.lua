require 'configs/hw_vars_1cell_1frha'

--************************************************************************************
--************************************************************************************
function get_ip(network_number)
    local _ip_ = ''
    local _index_ = 1
    for w in string.gmatch(network_number, "%d+") do
        _number_ = tostring(tonumber(w))

        if _index_ < 4 then
            _ip_=_ip_.._number_..'.'
        else
            _ip_=_ip_.._number_
        end
        _index_=_index_+1
    end
    return _ip_

end

--************************************************************************************
--************************************************************************************

NETWORK_NUMBER={
    NETWORK1_NUMBER='1.7',                   --
    NAT_NETWORK1_NUMBER = '11.7',            --
    NETWORK2_NUMBER='2.7',                   --
    NAT_NETWORK2_NUMBER = '12.7',             --
    NETWORK3_NUMBER='3.7',
    NAT_NETWORK3_NUMBER = '13.7',
    NETWORK4_NUMBER='4.7',
    NAT_NETWORK4_NUMBER = '14.7',
    NETWORK5_NUMBER='5.7',
    NAT_NETWORK5_NUMBER = '15.7',
    NETWORK6_NUMBER='6.7',
    NAT_NETWORK6_NUMBER = '16.7',
}

    SERVER_IP_UPLANE = '10.34.166.2:2152'        -- Second interface IP connected to IPHY FSM GE


--************************************************************************************
--************************************************************************************
--COUNTABLE PARAMETERES
UEC_ADDR    = NETWORK_NUMBER.NAT_NETWORK1_NUMBER..'.200'..'.200'
PGW_ADDR    = NETWORK_NUMBER.NETWORK1_NUMBER..'.'..'254'..'.'..'254'
UEC2_ADDR    = NETWORK_NUMBER.NAT_NETWORK2_NUMBER..'.200'..'.200'
PGW2_ADDR    = NETWORK_NUMBER.NETWORK2_NUMBER..'.'..'254'..'.'..'254'
UEC3_ADDR    = NETWORK_NUMBER.NAT_NETWORK3_NUMBER..'.200'..'.200'
PGW3_ADDR    = NETWORK_NUMBER.NETWORK3_NUMBER..'.'..'254'..'.'..'254'
UEC4_ADDR    = NETWORK_NUMBER.NAT_NETWORK4_NUMBER..'.200'..'.200'
PGW4_ADDR    = NETWORK_NUMBER.NETWORK4_NUMBER..'.'..'254'..'.'..'254'
UEC5_ADDR    = NETWORK_NUMBER.NAT_NETWORK5_NUMBER..'.200'..'.200'
PGW5_ADDR    = NETWORK_NUMBER.NETWORK5_NUMBER..'.'..'254'..'.'..'254'
UEC6_ADDR    = NETWORK_NUMBER.NAT_NETWORK6_NUMBER..'.200'..'.200'
PGW6_ADDR    = NETWORK_NUMBER.NETWORK6_NUMBER..'.'..'254'..'.'..'254'
--*****************************************************************************
--*****************************************************************************
-- SET VARIABLES
--exec('set DAEMON_PORT='..UEC_DAEMON_PORT)
--exec('set ENB_ADDR_1='..get_ip(ENB.ENB_ADDR_1))
--exec('set ENB_ADDR_2='..get_ip(ENB.ENB_ADDR_2))
--
--exec('set S1_ADDR='..'"'..S1.S1_ADDR..'"')
--exec('set S1U_ADDR='..'"'..S1.S1U_ADDR..'"')
--exec('set S11_ADDR='..'"'..S1.S11_ADDR..'"')
--
--exec('set UE_COUNT='..UE_COUNT)
exec('set PGW_ADDR='..get_ip(PGW_ADDR))
exec('set PGW2_ADDR='..get_ip(PGW2_ADDR))
exec('set PGW3_ADDR='..get_ip(PGW3_ADDR))
exec('set PGW4_ADDR='..get_ip(PGW4_ADDR))
exec('set PGW5_ADDR='..get_ip(PGW5_ADDR))
exec('set PGW6_ADDR='..get_ip(PGW6_ADDR))
--
exec('set UEC1_ADDR='..get_ip(UEC_ADDR))
exec('set UEC2_ADDR='..get_ip(UEC2_ADDR))
exec('set UEC3_ADDR='..get_ip(UEC3_ADDR))
exec('set UEC4_ADDR='..get_ip(UEC4_ADDR))
exec('set UEC5_ADDR='..get_ip(UEC5_ADDR))
exec('set UEC6_ADDR='..get_ip(UEC6_ADDR))

exec('set UEC1_PIP="'..PIP_ADDR[1][1]..'"')
exec('set UEC1_PIP_UPLANE="'..SERVER_IP_UPLANE..'"')
exec('set UEC2_PIP="10.34.166.3:2152"')
exec('set UEC2_PIP_UPLANE="10.34.166.4:2152"')
exec('set UEC3_PIP="10.34.166.5:2152"')
exec('set UEC3_PIP_UPLANE="10.34.166.6:2152"')
exec('set UEC4_PIP="10.34.166.7:2152"')
exec('set UEC4_PIP_UPLANE="10.34.166.8:2152"')
exec('set UEC5_PIP="10.34.166.9:2152"')
exec('set UEC5_PIP_UPLANE="10.34.166.10:2152"')
exec('set UEC6_PIP="10.34.166.11:2152"')
exec('set UEC6_PIP_UPLANE="10.34.166.12:2152"')


--***************************************************************
--***************************************************************
-- BEGIN CONFIGURATION
sim_ = sim()
if (sim.INIT == sim_.state) then
    sim_:configure()
    exec('debug_log gate=1 level=0')
end


exec('set_mme id=1 type=simulated ip='..EPC_SERVER_IP..':'..EPC_DAEMON_PORT..'  s1='..S1_IP[1].. ':36412 mmegi=1 mmec=3')
exec('set_sgw id=1 type=simulated ip='..EPC_SERVER_IP..':'..EPC_DAEMON_PORT..' s1u='..S1U_IP[1][1]..':2152  s11='..S1_IP[1]..':2153')
exec('set_pgw id=1 type=simulated ip='..EPC_SERVER_IP..':'..EPC_DAEMON_PORT..' apn=ulm1.net devtype=tun devname=tunPGW1 addr=$PGW_ADDR/16')
exec('set_pgw id=2 type=simulated ip='..EPC_SERVER_IP..':'..EPC_DAEMON_PORT..' apn=ulm2.net devtype=tun devname=tunPGW2 addr=$PGW2_ADDR/16')
--exec('set_pgw id=3 type=simulated ip='..EPC_SERVER_IP..':'..EPC_DAEMON_PORT..' apn=ulm3.net devtype=tun devname=tunPGW3 addr=$PGW3_ADDR/16')

exec('set_enb type=external id=1 plmn='..PLMN..' s1=' ..ENB_ADDR[1]..' enb_id_macro=' .. string.format("0x%05X",ENB_IDS))

for cell_id=1,#CELLS do
    exec('set_cell id=' .. CELLS[cell_id] .. ' enb=1 tac=130 proxy='..PROXY_ADDR[1]..' eci=' .. string.format("0x%07X",ENB_IDS*0x100 + CELLS[cell_id]))
    end
--
exec('set_uec id=1 ip='..UEC_SERVER_IP..':'..UEC_DAEMON_PORT..' gtpu=on pdn=1 addr=$UEC1_ADDR/16 peer=$UEC1_PIP peer_uplane=$UEC1_PIP_UPLANE retries=unlimited')
--exec('set_uec id=2 ip='..UEC_SERVER_IP..':'..UEC_DAEMON_PORT..' gtpu=on pdn=2 addr=$UEC2_ADDR/16 peer=$UEC2_PIP peer_uplane=$UEC2_PIP_UPLANE retries=unlimited')
--exec('set_uec id=3 ip='..UEC_SERVER_IP..':'..UEC_DAEMON_PORT..' gtpu=on pdn=3 addr=$UEC3_ADDR/16 peer=$UEC3_PIP peer_uplane=$UEC3_PIP_UPLANE retries=unlimited')
exec('set_param SEC_OP_KEY=ABCDEF0123456789ABCDEF0123456789')

sec_key=string.sub(sec_key,1,27) -- cut lenght of sec_key

--for cell_id=1,#CELLS do
  --  for ue_index=1,UE_COUNT do
--
  --          ue_id = CELLS[cell_id] * BASE_ID + ue_index
  --          _sec_key_ = sec_key .. string.format("%02X", CELLS[cell_id]) .. string.format("%03d", ue_index)
  --          _imsi_low_ = 111110000 + ue_id
  --          _imsi_ = '244:09:'.._imsi_low_
  --
  --         exec('set_ue id='..ue_id..' sec_key='.._sec_key_..' imsi='.._imsi_..' cell='..CELLS[cell_id]..' enb=1')
  --          exec('set_bearer id=1 ue='..ue_id..' trf_type=internal default=on qci=8 ')
  --          exec('set_bearer id=2 ue='..ue_id..' qci=1 gbr_ul=31 gbr_dl=31 mbr_ul=31 mbr_dl=31 ')
  --          -- PDN 2
  --         exec('set_bearer id=3 ue='..ue_id..' pdn=2 trf_type=internal default=on qci=8 ')
  --          exec('set_bearer id=4 ue='..ue_id..' pdn=2 qci=1 gbr_ul=31 gbr_dl=31 mbr_ul=31 mbr_dl=31 ')
  --          exec('set_bearer id=5 ue='..ue_id..' pdn=2 qci=2 gbr_ul=31 gbr_dl=31 mbr_ul=31 mbr_dl=31 ')
  --          exec('set_bearer id=6 ue='..ue_id..' pdn=2 qci=3 gbr_ul=50 gbr_dl=50 mbr_ul=50 mbr_dl=50 ')

--    end -- for ue_index
--end -- for cell_id

-- ue_group=1
--
        seq_nr=0
        for cell_id=1,#CELLS do
            exec('set_ue_group simulated id='..cell_id..' category=12 uec='..cell_id..' pdn='..cell_id..' eia=null+snow3g eea=null+snow3g cell='..CELLS[cell_id])


            exec('set_bearer id=9 ue_group='..cell_id..' priority=9 default=on pdn='..cell_id..' qci=9 trf_type=internal')
	    exec('set_bearer id=1 ue_group='..cell_id..' priority=2 pdn='..cell_id..' qci=1 gbr_ul=31 gbr_dl=31 mbr_ul=31 mbr_dl=31')
            exec('set_bearer id=2 ue_group='..cell_id..' priority=4 pdn='..cell_id..' qci=2 gbr_ul=31 gbr_dl=31 mbr_ul=144 mbr_dl=144')
	    exec('set_bearer id=4 ue_group='..cell_id..' priority=5 pdn='..cell_id..' qci=4 gbr_ul=31 gbr_dl=31 mbr_ul=32 mbr_dl=320')
	    exec('set_bearer id=3 ue_group='..cell_id..' priority=3 pdn='..cell_id..' qci=3 gbr_ul=31 gbr_dl=31 mbr_ul=64 mbr_dl=128')
	    exec('set_bearer id=5 ue_group='..cell_id..' priority=1 pdn='..cell_id..' qci=5')
            exec('set_bearer id=6 ue_group='..cell_id..' priority=6 pdn='..cell_id..' qci=6')
            exec('set_bearer id=7 ue_group='..cell_id..' priority=7 pdn='..cell_id..' qci=7')
            exec('set_bearer id=8 ue_group='..cell_id..' priority=8 pdn='..cell_id..' qci=8')

            for imsi=1,UE_COUNT+850 do
                exec('set_ue id='.. cell_id*(BASE_ID+750) +10000+imsi ..' group='..cell_id..' imsi=244:09:'..cell_id..'0000'.. 10000 +imsi .. ' cell='..CELLS[cell_id])
				exec('ue_param id='.. cell_id*(BASE_ID+750) +10000+imsi ..' ue_eutra_capabilities=c9ba050600106260c89b0d18391ff8c188ffc60c47fe30f23ff1bd11ff8dfc8ffc69e47fffd3ffa6a2087004830d493952207058c08000000b88bc0c0000400308001000c600040034c001000c3000400344001000db000400700001010820028010308001001c000040460800a0040c6000400700001014c2002801034c001000c20004807080010108200384000808c1201420818c000900e1000242304005082463000200384000808c1001420818c000800e100020298400508206980020038400090a6100142091a6000800e1000202d8400508206d80020018c000900e300020230400718001014c20028c1034c001001c6000405b0800a3040db000400718001216c20028c1236c001002c000040420808c10024008184000808c1002400808410318001002c00004042080a61002400818400080a6100240080841034c001002c20004046080a61002420818c00080a61002420808c1034c001002c20004046080b61002420818c00080b61002420808c1036c001001c3000405b080be30723ff18311ff8c188ffc61e47fe37a23ff1bf91ff8d3c8ffc6ce47fe36723ff1af91ff8d7c8ffc6be47fe35f23ff1bf91ff8dfc8ffc6fe47fe37f23ff1bf91ff8dfc8ffc66c47fe33623ff19791ff8cbc8ffc6fe47fe37f23ff1b791ff8dbc8ffc6fe47fe37f23ff1af91ff8d7c8ffc6be47fe35f23ff1bf91ff8dfc8ffc6fe47fe37f23ff1bf91ff8dfc8ffc6fe47fe37f23ff1bf91ff8dfc8ffc6fe47fe37f23ff1bf91ff8dfc8ffc6fe47fc00d00000d78001fe00000007f80000001fe00000001fe00000007f80000001fe00000007f800000001ff00000007f80000001fe00000007f80000001fe00000007f80000000000110040')

            end
end

--turn off console prints (except errors and abnormal case reports)
exec('mme_param id=1 disable_print=all')
exec('debug_log level=6')
exec('set_log log_to_file=on')
exec('cfg_end')

--###################################################################
-- create_file with configuration script result
--###################################################################
filename = "EPC_SIM_Egate_config_result.txt"

os.remove(filename)

if (sim_.state == sim.CONFIGURED) then
    filetext = "EPC_SIM state is CONFIGURED\n"
else
    filetext = "EPC_SIM state is NOT CONFIGURED\n"
end

local resultFile = io.open(filename,"w")
resultFile:write(filetext)
resultFile:close()

sleep (2)

